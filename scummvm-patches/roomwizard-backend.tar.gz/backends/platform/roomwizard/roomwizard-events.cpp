/* ScummVM - Graphic Adventure Engine
 *
 * ScummVM is the legal property of its developers, whose names
 * are too numerous to list here. Please refer to the COPYRIGHT
 * file distributed with this source distribution.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "backends/platform/roomwizard/roomwizard-events.h"
#include "backends/platform/roomwizard/roomwizard.h"
#include "backends/platform/roomwizard/roomwizard-graphics.h"
#include "common/system.h"
#include "common/textconsole.h"
#include <stdlib.h>

RoomWizardEventSource::RoomWizardEventSource()
	: _touchInput(nullptr),
	  _touchInitialized(false),
	  _wasTouching(false),
	  _lastTouchX(0),
	  _lastTouchY(0),
	  _touchStartTime(0),
	  _gameWidth(320),
	  _gameHeight(200),
	  _gameOffsetX(0),
	  _gameOffsetY(0) {
	
	initTouch();
}

RoomWizardEventSource::~RoomWizardEventSource() {
	closeTouch();
}

void RoomWizardEventSource::initTouch() {
	if (_touchInitialized)
		return;

	_touchInput = (TouchInput *)malloc(sizeof(TouchInput));
	if (!_touchInput) {
		warning("Failed to allocate touch input structure");
		return;
	}

	if (touch_init(_touchInput, "/dev/input/event0") < 0) {
		warning("Failed to initialize touch input - device may not be available");
		free(_touchInput);
		_touchInput = nullptr;
		return;
	}

	// Set screen size for coordinate scaling
	touch_set_screen_size(_touchInput, 800, 480);
	
	_touchInitialized = true;
	warning("RoomWizard touch input initialized");
}

void RoomWizardEventSource::closeTouch() {
	if (_touchInitialized && _touchInput) {
		touch_close(_touchInput);
		free(_touchInput);
		_touchInput = nullptr;
		_touchInitialized = false;
	}
}

void RoomWizardEventSource::setGameScreenSize(int width, int height, int offsetX, int offsetY) {
	_gameWidth = width;
	_gameHeight = height;
	_gameOffsetX = offsetX;
	_gameOffsetY = offsetY;
	
	debug("Game screen size set to %dx%d at offset (%d, %d)", width, height, offsetX, offsetY);
}

void RoomWizardEventSource::transformCoordinates(int touchX, int touchY, int &gameX, int &gameY) {
	// Check if overlay (GUI) is visible - if so, use full screen coordinates
	// The overlay is 800x480 and used for the ScummVM GUI
	OSystem_RoomWizard *system = dynamic_cast<OSystem_RoomWizard *>(g_system);
	if (system && system->getGraphicsManager() && 
	    ((RoomWizardGraphicsManager *)system->getGraphicsManager())->isOverlayVisible()) {
		// Overlay uses full 800x480 resolution - no transformation needed
		gameX = touchX;
		gameY = touchY;
		
		// Clamp to overlay bounds
		if (gameX < 0) gameX = 0;
		if (gameY < 0) gameY = 0;
		if (gameX >= 800) gameX = 799;
		if (gameY >= 480) gameY = 479;
	} else {
		// Transform from framebuffer coordinates to game coordinates
		// Account for centering offset
		int fbOffsetX = (800 - _gameWidth) / 2;
		int fbOffsetY = (480 - _gameHeight) / 2;
		
		gameX = touchX - fbOffsetX;
		gameY = touchY - fbOffsetY;
		
		// Clamp to game bounds
		if (gameX < 0) gameX = 0;
		if (gameY < 0) gameY = 0;
		if (gameX >= _gameWidth) gameX = _gameWidth - 1;
		if (gameY >= _gameHeight) gameY = _gameHeight - 1;
	}
}

bool RoomWizardEventSource::pollEvent(Common::Event &event) {
	if (!_touchInitialized || !_touchInput) {
		return false;
	}

	// Poll touch input (non-blocking)
	int poll_result = touch_poll(_touchInput);
	
	TouchState state = touch_get_state(_touchInput);
	uint32 currentTime = g_system->getMillis();
	
	// Debug: Log when events are detected
	if (poll_result > 0) {
		warning("Touch events: %d, state: pressed=%d held=%d x=%d y=%d", 
		        poll_result, state.pressed, state.held, state.x, state.y);
	}

	// Check if touch state changed
	if (state.pressed && !_wasTouching) {
		warning("Touch STARTED at (%d, %d)", state.x, state.y);
		// Touch started
		_wasTouching = true;
		_lastTouchX = state.x;
		_lastTouchY = state.y;
		_touchStartTime = currentTime;

		// Generate mouse move + button down event
		int gameX, gameY;
		transformCoordinates(state.x, state.y, gameX, gameY);
		
		warning("Sending MOUSEMOVE to (%d, %d)", gameX, gameY);
		event.type = Common::EVENT_MOUSEMOVE;
		event.mouse.x = gameX;
		event.mouse.y = gameY;
		
		// Update cursor position directly
		g_system->warpMouse(gameX, gameY);
		
		// We'll send button down on next poll
		return true;
		
	} else if (state.pressed && _wasTouching) {
		// Touch continuing
		if (state.x != _lastTouchX || state.y != _lastTouchY) {
			// Touch moved
			_lastTouchX = state.x;
			_lastTouchY = state.y;

			int gameX, gameY;
			transformCoordinates(state.x, state.y, gameX, gameY);
			
			event.type = Common::EVENT_MOUSEMOVE;
			event.mouse.x = gameX;
			event.mouse.y = gameY;
			
			// Update cursor position directly
			g_system->warpMouse(gameX, gameY);
			
			return true;
		}
		
	} else if (!state.pressed && _wasTouching) {
		// Touch ended
		uint32 touchDuration = currentTime - _touchStartTime;
		_wasTouching = false;

		int gameX, gameY;
		transformCoordinates(_lastTouchX, _lastTouchY, gameX, gameY);

		// Check for long press (right-click)
		if (touchDuration >= LONG_PRESS_TIME) {
			event.type = Common::EVENT_RBUTTONUP;
		} else {
			event.type = Common::EVENT_LBUTTONUP;
		}
		
		event.mouse.x = gameX;
		event.mouse.y = gameY;
		return true;
	}

	// Check if we need to send button down after move
	if (_wasTouching && (currentTime - _touchStartTime) < 50) {
		// Send button down shortly after touch start
		int gameX, gameY;
		transformCoordinates(_lastTouchX, _lastTouchY, gameX, gameY);
		
		event.type = Common::EVENT_LBUTTONDOWN;
		event.mouse.x = gameX;
		event.mouse.y = gameY;
		return true;
	}

	return false;
}
